import{I as h,g as c,s as D,d as R,n as W,m as M,V as j,e as L,k as q,N as K,l as Y,T as B,b as O,o as Z,f as N,S as F}from"./index-CS3W2HgK.js";import{a as G,b as J,d as p}from"./three-C9ydRrYs.js";import{A as Q}from"./artLevel-CNtm5S0H.js";function U(t){const a=document.createElement("div");return a.className="hud",a.innerHTML=`
    <div class="alert-vignette suspicious"></div>
    <div class="hud-top">
      <div class="chip level-chip">${h.moon}<div><small>${c("house")} ${t.house}</small><b>${c("night")} ${t.level}</b></div></div>
      <div class="cookie-bar">
        ${Array.from({length:t.total},(n,o)=>`<div class="slot ${o<t.cookies?"got":""}">${h.cookie(o<t.cookies)}</div>`).join("")}
      </div>
      <button class="round-btn pause" aria-label="Pause">${h.pause}</button>
    </div>
    <div class="hud-sub">
      <div class="chip timer"><span class="clock"></span><b>0:${String(Math.floor(t.time)).padStart(2,"0")}</b><i>/ 0:35</i></div>
      <div class="chip stealth">${h.eye}<b>${c("hmm")}</b></div>
    </div>
    <div class="tip-card">
      <div class="tip-icon">${h.creak}</div>
      <div class="tip-text"><small>${c("newTip")}</small><b>${c("tip_creaky_t")}</b><span>${c("tip_creaky_d")}</span></div>
    </div>
    <div class="joystick">
      <div class="joy-run"></div>
      <div class="joy-tip"></div>
      <div class="joy-knob"></div>
      <div class="joy-label">tiptoe</div>
    </div>
    <button class="toy-btn" aria-label="${c("throwToy")}">
      <div class="toy-ring"></div>
      ${h.duck}
      <span class="toy-count">×${t.toys}</span>
    </button>
  `,{el:a,layout(n,o){a.classList.toggle("portrait",o>n)},update(n){const o=a.querySelector(".joy-knob");o.style.transform=`translate(${-26+Math.sin(n)*2}px, ${-18+Math.cos(n)*2}px)`}}}function so(t){const a=Q,n=B[a.house],o=new G;o.background=D(n.skyTop,n.skyBottom,!0,a.house);const w=new J(30,1,.1,200),v=R(a,n);o.add(v.root),W(o,{size:Math.max(a.w,a.d)+3,center:v.center,moon:1.05,fill:.72});const m=M("kid",F[0]);m.mode="tiptoe",m.speed=.5;const $=t?new p(2.35,0,6.35):new p(2.5,0,6.25);m.root.position.copy($),m.root.rotation.y=t?Math.PI*.62:Math.PI*.75,o.add(m.root);const i=M("mum");i.mode=t?"idle":"walk",i.speed=.5,i.root.position.set(5.9,0,5.95);const x=Math.PI;i.root.rotation.y=Math.atan2(Math.cos(x),Math.sin(x)),o.add(i.root);const r=M("cat");r.root.position.set(7.4,0,2.2),r.root.rotation.y=-.6,o.add(r.root);const e=M("vacuum");e.mode="walk",e.root.position.set(2,0,2.6),e.root.rotation.y=.9,o.add(e.root);const z=new j(3.9,.5);t&&z.setAlert("suspicious"),o.add(z.group);const C=new j(1.9,.62,{volume:!1,spot:!1,intensity:.7});o.add(C.group);const S=new j(1.3,.45,{volume:!1,spot:!1,intensity:.6});S.color.set(6222079),o.add(S.group);const b=L("Zzz","#cdd8ff");b.position.set(7.75,1.25,11.6),o.add(b);const T=L(t?"?":"…","#ff8a2f");T.visible=t,o.add(T);const I=q();I.position.set(.55,.03,6.4),o.add(I);const f=new K(1.6);f.mesh.position.set($.x,.03,$.z),f.mesh.visible=t,o.add(f.mesh);const P=[];let k=null;t?(k=U({house:1,level:3,cookies:1,total:3,time:23.4,toys:2}),P.push(k.el)):P.push(Y({house:c(`house_${a.house}`),night:3,name:c(a.nameKey),cookies:2,par:35}));const g=new p,V=[m,i,r,e];let y=1;return{scene:o,camera:w,overlay:P,resize(l,s){y=l/s;const d=Z(y,a.w,a.d),u=y<.9,A=u?[.01,.01,.1,.07]:[.04,.04,.1,.08];if(t){const _=new p(3.6,0,6.6),E=d?new p(3.2,0,5.8):new p(4.3,0,4.6);N(w,_.clone().sub(E),_.clone().add(E),y,{yaw:d?-d:0,margin:[0,0,0,0],pitchDeg:55,fov:u?34:28,height:0})}else N(w,new p(-.9,0,-.9),new p(a.w+.9,0,a.d+.9),y,{yaw:d?-d:0,margin:A,pitchDeg:55,fov:u?34:28});k?.layout(l,s)},update(l,s){if(!t){const u=5.2+Math.sin(s*.35)*.6;i.root.position.x=u}for(const u of V)O(u,l,s);i.root.updateMatrixWorld(!0),i.lightTip.getWorldPosition(g);const d=t?-.18:Math.sin(s*.8)*.25;z.update(i.root.position.x,i.root.position.z,x+d,g,v.walls,l,s),i.lookYaw=-d,r.root.updateMatrixWorld(!0),C.update(r.root.position.x,r.root.position.z,Math.PI*.62+Math.sin(s*.6)*.35,g.set(r.root.position.x,.3,r.root.position.z),v.walls,l,s),e.root.position.set(2+Math.sin(s*.4)*.5,0,2.6+Math.cos(s*.4)*.3),S.update(e.root.position.x,e.root.position.z,Math.atan2(Math.cos(e.root.rotation.y),Math.sin(e.root.rotation.y)),g.set(e.root.position.x,.1,e.root.position.z),v.walls,l,s),b.position.y=1.2+Math.sin(s*1.5)*.06,b.material.opacity=.75+Math.sin(s*1.5)*.25,T.position.set(i.root.position.x,2.05+Math.sin(s*4)*.04,i.root.position.z),f.update(s),I.rotation.z=s*.4,v.update(s,l),k?.update(s)}}}export{so as levelView};
